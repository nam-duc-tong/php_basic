<?php
    $some_number = [1,2,3,4,5,0,3,2];
    sort($some_number);
    // foreach($some_number as $key=>$value){
    //     echo "<pre>";
    //     echo "number [".$key."] = ".$value."\n";
    //     echo "</pre>";      
    // }
    // echo "<pre>";
    // print_r($some_number);
    // echo "</pre>";

    $student = [
       [
        'fullname' =>'Tong Duc Nam',
        'age'=> 23,
        'job' => "Lap trinh vien"
       ],
       [
        'fullname' =>'Tong Duc Nam',
        'age'=> 23,
        'job' => "Lap trinh vien"
       ],
       [
        'fullname' =>'Tong Duc Nam',
        'age'=> 23,
        'job' => "Lap trinh vien"
       ]
    ];
    print_r(json_encode($student));
?>