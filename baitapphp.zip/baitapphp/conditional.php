<?php
    // echo "We talk about conditional in php";
    // $date_time = date("F j h");
    // echo $date_time;

    $comment = [
        'hi','Good'
    ];
    // if(!isset($comment)){
    //     echo "No Comments";
    // }else{
    //     echo "array co phan tu ";
    // }
    $first_comment = $comment[1] ?? 'No Comments';
    // echo $first_comment;
    // echo !empty($comment) ? "The are comments": "No Comment";

    $favorite_color = 'green';
    switch($favorite_color){
        case 'red':
            echo "Day la mau do";
            break;
        case 'aqua':
            echo "Day la mau toi yeu thich";
            break;
        default:
            echo "Khong co cai nao dung ca";
            break;
    }
?>