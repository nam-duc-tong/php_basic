<?php
    echo "Cookies in PHP";
    // lưu dữ liệu trên trình duyệt
    // 
    setcookie("name","Tong Duc Nam",time() + 24*3600);
    if(isset($_COOKIE['name'])){
        echo $_COOKIE['name'];
    }
    setcookie('name','',time() - 24*3600);
?>