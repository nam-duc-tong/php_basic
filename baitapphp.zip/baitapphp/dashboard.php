<?php
    session_start();
    if(isset($_SESSION['email'])){
        echo "Welcome to Dashboard page ";
        echo "email: ".$_SESSION['email'];
        echo "<a href='/logout.php'>Logout</a>";
    }
    else{
        echo "Welcome guest to Dashboard";
        echo "<a href='/sessions.php'>Back to Login</a>";
    }
?>
<h1>Hello Ban</h1>  
