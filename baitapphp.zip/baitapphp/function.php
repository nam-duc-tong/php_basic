<?php
    // echo "This lesson is about function";
    $y = "Nam";
    function sayhello($name){
        $x = 123;
        global $y;
        echo "Hello $y";
        echo $name;
    }
    // sayhello("Tong Duc Nam");
    function sum($a,$b){
        return $a + $b;
    }
    // echo sum(8,9);
   $cong = function($a,$b){
    return $a + $b;
   };
//    echo $cong(9,123);

// arrow function 
   $sub = fn($a,$b)=>$a*$b;
//    echo $sub(9,12);
   $number = ['name','jon','huy','an'];
//    echo "Tong so phan tu trong mang = ".count($number);
//    var_dump(in_array('jon',$number));
   
//them phan tu cuoi
array_push($number,'Nam');
array_push($number,"Thanh");
//them phan tu o dau 
array_unshift($number,"Long");
   //xoa phan tu dau 
   //array_shift($number);
   //xoa phan tu cuoi
   //array_pop($number);
//    xoa phan tu bat ki
   unset($number[1]);
   $chuck_array = array_chunk($number,2);
//    print_r($chuck_array);

$array_one = [1,3,5];
$array_two = [2,4,6];
// merge hai mang
$merge_array = array_merge($array_one,$array_two);
//merge hai mang
$array_three = [...$merge_array];
// sort($merge_array);
// print_r($merge_array);
// print_r($array_three);
//merge hai mang
$array_four = [ ...$array_one,...$array_two];
// print_r($array_four);

$a = [1,2,3];
$b = ['hoang','nam','duc'];
$c = array_combine($a,$b);
// print_r(array_flip($c));
// print_r(array_values($c));


$number2 = range(0,9);
// print_r($number2);

$squared_numbers = array_map(function($each_number){
    return $each_number * $each_number;
},$number2);
// print_r($squared_numbers);

$filter_numbers = array_filter($number2,function($each_number){
    return $each_number%2!=0;
});
// print_r($filter_numbers);


?>