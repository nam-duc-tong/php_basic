<?php
//    $name = "Nam";
//    $age = 20;
//    echo "Toi ten la $name va toi $age tuoi";

// $sum ="1"+"2";
// echo 5/0;
// var_dump($sum);

?>