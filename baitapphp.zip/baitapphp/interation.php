<?php
    // echo "vong lap ";
    $i = 0;
    // while($i<20){
    //     echo "i = $i<br>";
    //     $i++;
    // }

    // do{
    //     echo "i = $i <br>";
    //     $i ++;
    // }while($i<30);

    $fruit = ['apple','pine','orange','lemon'];
    // for($i=0;$i<count($fruit);$i++){
    //     echo "$fruit[$i]<br>";
    // }

    foreach($fruit as $num => $value){
        echo "$num => $value<br>";
    }
?>