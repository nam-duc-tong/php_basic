<?php
    session_start();
    header('Location: ./sessions.php');
    session_destroy();
?>