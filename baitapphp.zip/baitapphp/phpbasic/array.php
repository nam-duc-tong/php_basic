<?php
    // echo "Page Array";
    $student = array("Tong","Duc","Nam");
    
    // print_r($student[2]);
    foreach($student as $key=>$value){
        echo "key: {$key} => Value: {$value}<br>";
    }
?>