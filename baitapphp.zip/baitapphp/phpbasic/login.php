<?php
    
    $username = $_GET['username'];

    $password = $_GET['password'];
    if(isset($_GET['username']) && isset($_GET['password'])){
        if($username == "nam@gmail.com"){
            echo "Ban da nhap dung email";
        }
        else{
            echo "Ban da nhap sai email. Nhap lai";
            ?>
            <a href="index.php">Quay lai</a>
            <?php
        }
    }
?>