<?php
session_start();

// echo "page account";
// cap nhat username: tongducnam =>laptrinhvien
$_SESSION['login']['username'] = 'laptrinhvien';
echo $_SESSION['login']['username'];
?>