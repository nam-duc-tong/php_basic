<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Chu</title>
</head>
<body>
    <?php
        if(isset($_SESSION['login']['username'])){
            ?>
            <a href="logout.php">Dang Xuat</a>
        <?php
        }
        else{
         ?>
            <a href="login.php">Dang Nhap</a>
         <?php   
        }
    ?>
    
    
    <hr>
    <h1>Unitop.vn</h1>
    <a href="index.php">Trang Chu</a>
    <a href="course.php">Khoa Hoc</a>
    <a href="account.php">Tai Khoan</a>
    <hr>
    <p>Trang Chu</p>

    <?php
        $username = 'tongducnam';
        // echo $username;
        if(isset($_SESSION['login']['username'])){
            echo "Xin chao <b>{$_SESSION['login']['username']}</b>";
        }
        else{
            echo 'Ban da dang xuat thanh cong';
        }
    ?>
</body>
</html>