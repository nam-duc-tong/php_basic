<?php
    session_start();
    $_SESSION['login']['username'] = 'tongducnam';
    echo "<pre>";
    // print_r($_SESSION);
    if(isset($_SESSION['login']['username']))
    {
        echo $_SESSION['login']['username'];
    }
?>
    <a href="index.php">Trang Chu</a>
