<?php
    session_start();
    // session_destroy();
    // echo $_SESSION['login']['username'];
    //xoa session
    unset($_SESSION['login']);
    
    header('Location: index.php');
?>
<!-- <a href="index.php">Trang chu</a> -->