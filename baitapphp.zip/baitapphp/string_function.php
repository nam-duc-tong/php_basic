<?php
    // echo "String function";
    $fullname = "Tong Duc Nam";
    echo "Length: ".strlen($fullname);
    // echo strtolower($fullname);
    // echo strtoupper($fullname);
    echo str_replace(' ','-',$fullname);
?>